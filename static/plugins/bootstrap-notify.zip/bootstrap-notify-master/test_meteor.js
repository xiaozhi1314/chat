Tinytest.add('Instantiation', function(test) {
  test.notEqual($.notify, undefined);
});
